import SwiftUI
import WebKit
import QuickLook

struct ActiveDownload: Identifiable {
    var id: UUID
    var name: String
    var progress: Double
}

final class DownloadManager: NSObject, ObservableObject, WKDownloadDelegate {
    static let shared = DownloadManager()
    @Published var active: [ActiveDownload] = []
    @Published var files: [URL] = []
    private var tasks: [ObjectIdentifier: (id: UUID, dest: URL, obs: NSKeyValueObservation)] = [:]

    let folder: URL = {
        let d = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Downloads", isDirectory: true)
        try? FileManager.default.createDirectory(at: d, withIntermediateDirectories: true)
        return d
    }()

    override init() { super.init(); refresh() }

    func refresh() {
        let urls = (try? FileManager.default.contentsOfDirectory(
            at: folder, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
        let busy = Set(tasks.values.map { $0.dest })
        files = urls.filter { !busy.contains($0) }.sorted { modDate($0) > modDate($1) }
    }

    func delete(_ url: URL) {
        try? FileManager.default.removeItem(at: url)
        refresh()
    }

    private func modDate(_ u: URL) -> Date {
        (try? u.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate) ?? .distantPast
    }

    private func uniqueURL(_ name: String) -> URL {
        let clean = name.replacingOccurrences(of: "/", with: "_")
        var url = folder.appendingPathComponent(clean.isEmpty ? "download" : clean)
        let base = url.deletingPathExtension().lastPathComponent
        let ext = url.pathExtension
        var i = 1
        while FileManager.default.fileExists(atPath: url.path) {
            url = folder.appendingPathComponent(ext.isEmpty ? "\(base) (\(i))" : "\(base) (\(i)).\(ext)")
            i += 1
        }
        return url
    }

    private func setProgress(_ id: UUID, _ value: Double) {
        if let i = active.firstIndex(where: { $0.id == id }) { active[i].progress = value }
    }

    private func finish(_ d: WKDownload, failed: Bool) {
        guard let t = tasks.removeValue(forKey: ObjectIdentifier(d)) else { return }
        t.obs.invalidate()
        if failed { try? FileManager.default.removeItem(at: t.dest) }
        active.removeAll { $0.id == t.id }
        refresh()
    }

    // MARK: WKDownloadDelegate
    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                  suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let dest = uniqueURL(suggestedFilename)
        let id = UUID()
        let obs = download.progress.observe(\.fractionCompleted) { [weak self] p, _ in
            let v = p.fractionCompleted
            DispatchQueue.main.async { self?.setProgress(id, v) }
        }
        tasks[ObjectIdentifier(download)] = (id, dest, obs)
        active.append(ActiveDownload(id: id, name: dest.lastPathComponent, progress: 0))
        completionHandler(dest)
    }

    func downloadDidFinish(_ download: WKDownload) { finish(download, failed: false) }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        finish(download, failed: true)
    }
}

struct DownloadsView: View {
    @ObservedObject private var dm = DownloadManager.shared
    @State private var preview: URL?
    @State private var flashItem: FlashItem?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                if !dm.active.isEmpty {
                    Section("Đang tải") {
                        ForEach(dm.active) { a in
                            VStack(alignment: .leading) {
                                Text(a.name).lineLimit(1)
                                ProgressView(value: a.progress)
                            }
                        }
                    }
                }
                Section("Đã tải") {
                    if dm.files.isEmpty {
                        Text("Chưa có tệp nào").foregroundStyle(.secondary)
                    }
                    ForEach(dm.files, id: \.self) { u in
                        HStack {
                            Button {
                                if u.pathExtension.lowercased() == "swf" { flashItem = FlashItem(url: u) } else { preview = u }
                            } label: { Text(u.lastPathComponent).lineLimit(2) }
                                .buttonStyle(.borderless)
                            Spacer()
                            ShareLink(item: u) { Image(systemName: "square.and.arrow.up") }
                                .buttonStyle(.borderless)
                        }
                    }
                    .onDelete { idx in
                        let items = idx.map { dm.files[$0] }
                        items.forEach { dm.delete($0) }
                    }
                }
            }
            .navigationTitle("Tải xuống")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Xong") { dismiss() } } }
            .quickLookPreview($preview)
            .fullScreenCover(item: $flashItem) { FlashPlayerView(file: $0.url) }
            .onAppear { dm.refresh() }
        }
    }
}
