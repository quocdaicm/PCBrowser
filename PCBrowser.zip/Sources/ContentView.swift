import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: SiteStore
    @State private var showAdd = false
    @State private var showDownloads = false
    @State private var showRename = false
    @State private var renameID: UUID?
    @State private var newName = ""
    @State private var opened: Site?

    var body: some View {
        NavigationStack {
            Group {
                if store.sites.isEmpty {
                    ContentUnavailableView("Chưa có trang nào", systemImage: "desktopcomputer",
                        description: Text("Bấm + để thêm trang web cần mở bằng giao diện máy tính."))
                } else {
                    List {
                        ForEach(store.sites) { s in
                            Button { opened = s } label: {
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(s.name).font(.headline)
                                    Text(s.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                    Text(s.mode.title).font(.caption2).foregroundStyle(.blue)
                                }
                            }
                            .contextMenu {
                                Button { UIPasteboard.general.string = s.url } label: {
                                    Label("Sao chép địa chỉ", systemImage: "link")
                                }
                                Button {
                                    store.sites.append(Site(name: s.name + " 2", url: s.url, mode: s.mode))
                                } label: { Label("Nhân bản (tài khoản mới)", systemImage: "plus.square.on.square") }
                                Button {
                                    renameID = s.id; newName = s.name; showRename = true
                                } label: { Label("Đổi tên", systemImage: "pencil") }
                            }
                        }
                        .onDelete(perform: store.remove)
                    }
                }
            }
            .navigationTitle("Trình duyệt PC")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { showDownloads = true } label: { Image(systemName: "arrow.down.circle") }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button { showAdd = true } label: { Image(systemName: "plus") }
                }
            }
            .sheet(isPresented: $showAdd) { AddSiteView() }
            .sheet(isPresented: $showDownloads) { DownloadsView() }
            .alert("Đổi tên", isPresented: $showRename) {
                TextField("Tên", text: $newName)
                Button("Lưu") {
                    if let id = renameID, var site = store.sites.first(where: { $0.id == id }), !newName.isEmpty {
                        site.name = newName
                        store.update(site)
                    }
                }
                Button("Hủy", role: .cancel) {}
            }
            .fullScreenCover(item: $opened) { s in
                BrowserView(site: s, onChange: { store.update($0) })
            }
        }
    }
}

struct AddSiteView: View {
    @EnvironmentObject var store: SiteStore
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var url = ""
    @State private var mode: DeviceMode = .winChrome

    private let presets: [(String, String, DeviceMode)] = [
        ("Zalo Web", "https://chat.zalo.me", .macSafari),
        ("Facebook", "https://www.facebook.com", .winChrome),
        ("Messenger", "https://www.messenger.com", .winChrome),
        ("Telegram Web", "https://web.telegram.org/k/", .macSafari),
        ("Gmail", "https://mail.google.com", .winChrome),
        ("TikTok", "https://www.tiktok.com", .winChrome),
    ]

    var body: some View {
        NavigationStack {
            Form {
                Section("Thông tin") {
                    TextField("Tên (tuỳ chọn)", text: $name)
                    TextField("Địa chỉ trang web", text: $url)
                        .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    Picker("Giả làm thiết bị", selection: $mode) {
                        ForEach(DeviceMode.allCases) { Text($0.title).tag($0) }
                    }
                }
                Section("Gợi ý") {
                    ForEach(presets, id: \.0) { p in
                        Button(p.0) { name = p.0; url = p.1; mode = p.2 }
                    }
                }
                Section { Text("Mỗi mục có kho đăng nhập riêng. Thêm cùng một trang nhiều lần để dùng nhiều tài khoản.")
                    .font(.footnote).foregroundStyle(.secondary) }
            }
            .navigationTitle("Thêm trang")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Hủy") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lưu") {
                        guard !url.trimmingCharacters(in: .whitespaces).isEmpty else { return }
                        let u = normalizeURL(url)
                        store.sites.append(Site(name: name.isEmpty ? (u.host ?? url) : name,
                                                url: u.absoluteString, mode: mode))
                        dismiss()
                    }
                }
            }
        }
    }
}
