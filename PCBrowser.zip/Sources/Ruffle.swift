import SwiftUI
import WebKit

enum RuffleAssets {
    static let scheme = "ruffle-res"

    static var folder: URL? { Bundle.main.url(forResource: "ruffle", withExtension: nil) }
    static var available: Bool { polyfill != nil }

    /// Mã chèn vào trang web để Ruffle tự thay nội dung Flash (polyfill).
    static let polyfill: String? = {
        guard let u = folder?.appendingPathComponent("ruffle.js"),
              let s = try? String(contentsOf: u, encoding: .utf8) else { return nil }
        let cfg = "window.RufflePlayer=window.RufflePlayer||{};"
            + "window.RufflePlayer.config=Object.assign({publicPath:'\(scheme)://app/'},window.RufflePlayer.config||{});\n"
        return cfg + s
    }()
}

/// Phục vụ file của Ruffle (trong app) và file .swf đã tải qua địa chỉ ruffle-res://app/...
final class RuffleSchemeHandler: NSObject, WKURLSchemeHandler {
    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL)); return
        }
        var path = url.path
        if path.isEmpty || path == "/" { path = "/player.html" }
        let name = (path as NSString).lastPathComponent
        let fileURL: URL?
        if path.hasPrefix("/file/") {
            fileURL = DownloadManager.shared.folder.appendingPathComponent(name)   // chỉ lấy tên file, chặn ../
        } else {
            fileURL = RuffleAssets.folder?.appendingPathComponent(name)
        }
        guard let f = fileURL, let data = try? Data(contentsOf: f, options: .mappedIfSafe) else {
            let r = HTTPURLResponse(url: url, statusCode: 404, httpVersion: "HTTP/1.1",
                                    headerFields: ["Access-Control-Allow-Origin": "*"])!
            urlSchemeTask.didReceive(r)
            urlSchemeTask.didFinish()
            return
        }
        let r = HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: [
            "Content-Type": mime(for: f.pathExtension.lowercased()),
            "Content-Length": "\(data.count)",
            "Access-Control-Allow-Origin": "*",
        ])!
        urlSchemeTask.didReceive(r)
        urlSchemeTask.didReceive(data)
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}

    private func mime(for ext: String) -> String {
        switch ext {
        case "js": return "text/javascript"
        case "wasm": return "application/wasm"
        case "html": return "text/html; charset=utf-8"
        case "swf": return "application/x-shockwave-flash"
        default: return "application/octet-stream"
        }
    }
}

struct FlashItem: Identifiable {
    let url: URL
    var id: URL { url }
}

struct RuffleWebView: UIViewRepresentable {
    let file: URL

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.setURLSchemeHandler(RuffleSchemeHandler(), forURLScheme: RuffleAssets.scheme)
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        let w = WKWebView(frame: .zero, configuration: cfg)
        w.backgroundColor = .black
        w.scrollView.backgroundColor = .black
        w.isInspectable = true
        var c = URLComponents()
        c.scheme = RuffleAssets.scheme
        c.host = "app"
        c.path = "/player.html"
        c.queryItems = [URLQueryItem(name: "swf", value: "file/" + file.lastPathComponent)]
        if let u = c.url { w.load(URLRequest(url: u)) }
        return w
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct FlashPlayerView: View {
    let file: URL
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack(alignment: .topTrailing) {
            RuffleWebView(file: file).ignoresSafeArea()
            Button { dismiss() } label: {
                Image(systemName: "xmark.circle.fill").font(.title)
                    .foregroundStyle(.white, .black.opacity(0.5))
            }
            .padding(12)
        }
        .background(Color.black)
    }
}
