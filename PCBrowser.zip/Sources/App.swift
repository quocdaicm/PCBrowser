import SwiftUI
import WebKit

@main
struct PCBrowserApp: App {
    @StateObject private var store = SiteStore()
    var body: some Scene {
        WindowGroup { ContentView().environmentObject(store) }
    }
}

enum DeviceMode: String, Codable, CaseIterable, Identifiable {
    case macSafari, winChrome, winEdge
    var id: String { rawValue }

    var title: String {
        switch self {
        case .macSafari: return "Mac (Safari)"
        case .winChrome: return "Windows (Chrome)"
        case .winEdge: return "Windows (Edge)"
        }
    }

    var userAgent: String {
        switch self {
        case .macSafari:
            return "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"
        case .winChrome:
            return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
        case .winEdge:
            return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0"
        }
    }

    /// JS chạy trước khi trang tải: giả navigator để khớp với User-Agent.
    var spoofScript: String {
        let platform = self == .macSafari ? "MacIntel" : "Win32"
        let vendor = self == .macSafari ? "Apple Computer, Inc." : "Google Inc."
        let brand = self == .winEdge ? "Microsoft Edge" : "Google Chrome"
        let uaData: String
        if self == .macSafari {
            uaData = "def(N,'userAgentData',undefined);"
        } else {
            uaData = """
            var brands=[{brand:'Chromium',version:'130'},{brand:'\(brand)',version:'130'},{brand:'Not?A_Brand',version:'99'}];
            var hi={brands:brands,mobile:false,platform:'Windows',platformVersion:'10.0.0',architecture:'x86',bitness:'64',model:'',uaFullVersion:'130.0.0.0'};
            def(N,'userAgentData',{brands:brands,mobile:false,platform:'Windows',
              getHighEntropyValues:function(h){return Promise.resolve(hi)},
              toJSON:function(){return {brands:brands,mobile:false,platform:'Windows'}}});
            """
        }
        return """
        (function(){
          function def(o,k,v){try{Object.defineProperty(o,k,{get:function(){return v},configurable:true})}catch(e){}}
          var N=Navigator.prototype;
          def(N,'platform','\(platform)');
          def(N,'vendor','\(vendor)');
          def(N,'maxTouchPoints',0);
          \(uaData)
        })();
        """
    }
}

struct Site: Identifiable, Codable, Hashable {
    var id = UUID()          // cũng là ID kho dữ liệu riêng (cookie, đăng nhập)
    var name: String
    var url: String
    var mode: DeviceMode
    var flash: Bool? = nil     // bật Ruffle (Flash) cho mục này
    var useFlash: Bool { flash ?? false }
}

func normalizeURL(_ text: String) -> URL {
    let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
    let l = t.lowercased()
    if (l.hasPrefix("http://") || l.hasPrefix("https://")), let u = URL(string: t) { return u }
    if !t.contains(" "), t.contains("."), let u = URL(string: "https://" + t) { return u }
    var c = URLComponents(string: "https://www.google.com/search")!
    c.queryItems = [URLQueryItem(name: "q", value: t)]
    return c.url!
}

final class SiteStore: ObservableObject {
    @Published var sites: [Site] = [] { didSet { save() } }
    private let key = "pcbrowser.sites"

    init() {
        if let d = UserDefaults.standard.data(forKey: key),
           let s = try? JSONDecoder().decode([Site].self, from: d) { sites = s }
    }

    private func save() {
        if let d = try? JSONEncoder().encode(sites) { UserDefaults.standard.set(d, forKey: key) }
    }

    func update(_ site: Site) {
        if let i = sites.firstIndex(where: { $0.id == site.id }) { sites[i] = site }
    }

    func remove(at offsets: IndexSet) {
        let ids = offsets.map { sites[$0].id }
        sites.remove(atOffsets: offsets)
        Task { for id in ids { try? await WKWebsiteDataStore.remove(forIdentifier: id) } }
    }
}
