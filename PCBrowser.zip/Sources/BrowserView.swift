import SwiftUI
import WebKit

// MARK: - Một thẻ (tab)
final class BrowserModel: NSObject, ObservableObject, Identifiable, WKNavigationDelegate, WKUIDelegate {
    let id = UUID()
    let webView: WKWebView
    var onOpenTab: ((URL) -> Void)?
    @Published var addressText = ""
    @Published var canGoBack = false
    @Published var canGoForward = false
    @Published var progress = 0.0
    @Published var pageTitle = ""
    @Published var mode: DeviceMode
    var flash: Bool
    private var observers: [NSKeyValueObservation] = []

    init(site: Site, mode: DeviceMode, flash: Bool, startURL: String) {
        self.mode = mode
        self.flash = flash
        let cfg = WKWebViewConfiguration()
        // Cùng một tài khoản: mọi thẻ dùng chung kho đăng nhập của mục này
        cfg.websiteDataStore = WKWebsiteDataStore(forIdentifier: site.id)
        cfg.allowsInlineMediaPlayback = true
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.defaultWebpagePreferences.preferredContentMode = .desktop
        cfg.setURLSchemeHandler(RuffleSchemeHandler(), forURLScheme: RuffleAssets.scheme)
        webView = WKWebView(frame: .zero, configuration: cfg)
        super.init()
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.isInspectable = true
        webView.isFindInteractionEnabled = true
        applyMode(mode, reload: false)
        observers = [
            webView.observe(\.url) { [weak self] w, _ in self?.addressText = w.url?.absoluteString ?? "" },
            webView.observe(\.canGoBack) { [weak self] w, _ in self?.canGoBack = w.canGoBack },
            webView.observe(\.canGoForward) { [weak self] w, _ in self?.canGoForward = w.canGoForward },
            webView.observe(\.title) { [weak self] w, _ in self?.pageTitle = w.title ?? "" },
            webView.observe(\.estimatedProgress) { [weak self] w, _ in self?.progress = w.estimatedProgress },
        ]
        load(startURL)
    }

    func applyMode(_ m: DeviceMode, reload: Bool) {
        mode = m
        refreshScripts(reload: reload)
    }

    func setFlash(_ on: Bool, reload: Bool) {
        flash = on
        refreshScripts(reload: reload)
    }

    private func refreshScripts(reload: Bool) {
        webView.customUserAgent = mode.userAgent
        let ucc = webView.configuration.userContentController
        ucc.removeAllUserScripts()
        ucc.addUserScript(WKUserScript(source: mode.spoofScript, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        if flash, let src = RuffleAssets.polyfill {
            ucc.addUserScript(WKUserScript(source: src, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        }
        if reload { webView.reload() }
    }

    func showFind() { webView.findInteraction?.presentFindNavigator(showingReplace: false) }

    func clearData() {
        webView.configuration.websiteDataStore.removeData(
            ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) { [weak self] in
            self?.webView.reload()
        }
    }

    func load(_ text: String) { webView.load(URLRequest(url: normalizeURL(text))) }

    // MARK: Delegates
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 preferences: WKWebpagePreferences,
                 decisionHandler: @escaping (WKNavigationActionPolicy, WKWebpagePreferences) -> Void) {
        preferences.preferredContentMode = .desktop
        if navigationAction.shouldPerformDownload { decisionHandler(.download, preferences); return }
        decisionHandler(.allow, preferences)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if let http = navigationResponse.response as? HTTPURLResponse,
           let cd = http.value(forHTTPHeaderField: "Content-Disposition"),
           cd.lowercased().hasPrefix("attachment") {
            decisionHandler(.download); return
        }
        decisionHandler(navigationResponse.canShowMIMEType ? .allow : .download)
    }

    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = DownloadManager.shared
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = DownloadManager.shared
    }

    // Link mở cửa sổ mới (target=_blank, window.open) -> mở thành thẻ mới
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url, url.scheme?.hasPrefix("http") == true, let open = onOpenTab {
            open(url)
        } else if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }

    func webView(_ webView: WKWebView, requestMediaCapturePermissionFor origin: WKSecurityOrigin,
                 initiatedByFrame frame: WKFrameInfo, type: WKMediaCaptureType,
                 decisionHandler: @escaping (WKPermissionDecision) -> Void) {
        decisionHandler(.grant)
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        if let vc = topVC() { vc.present(a, animated: true) } else { completionHandler() }
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Hủy", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        if let vc = topVC() { vc.present(a, animated: true) } else { completionHandler(false) }
    }

    private func topVC() -> UIViewController? {
        let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
        var vc = scene?.windows.first(where: \.isKeyWindow)?.rootViewController
        while let p = vc?.presentedViewController { vc = p }
        return vc
    }
}

// MARK: - Phiên duyệt web: nhiều thẻ của cùng một tài khoản
final class BrowserSession: ObservableObject {
    private(set) var site: Site
    @Published var mode: DeviceMode
    @Published var flash: Bool
    @Published var tabs: [BrowserModel] = []
    @Published var selected: UUID?

    init(site: Site) {
        self.site = site
        self.mode = site.mode
        self.flash = site.useFlash
        addTab(site.url)
    }

    var current: BrowserModel? { tabs.first { $0.id == selected } ?? tabs.last }

    @discardableResult
    func addTab(_ url: String? = nil) -> BrowserModel {
        let m = BrowserModel(site: site, mode: mode, flash: flash, startURL: url ?? site.url)
        m.onOpenTab = { [weak self] u in self?.addTab(u.absoluteString) }
        tabs.append(m)
        selected = m.id
        return m
    }

    func close(_ m: BrowserModel) {
        guard let i = tabs.firstIndex(where: { $0.id == m.id }) else { return }
        tabs.remove(at: i)
        if selected == m.id { selected = tabs.isEmpty ? nil : tabs[min(i, tabs.count - 1)].id }
    }

    func setMode(_ m: DeviceMode) {
        mode = m
        site.mode = m
        tabs.forEach { $0.applyMode(m, reload: true) }
    }

    func setFlash(_ on: Bool) {
        flash = on
        site.flash = on
        tabs.forEach { $0.setFlash(on, reload: true) }
    }
}

struct WebContainer: UIViewRepresentable {
    let webView: WKWebView
    func makeUIView(context: Context) -> WKWebView { webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

// MARK: - Màn hình trình duyệt
struct BrowserView: View {
    @StateObject private var session: BrowserSession
    let onChange: (Site) -> Void
    @Environment(\.dismiss) private var dismiss

    init(site: Site, onChange: @escaping (Site) -> Void) {
        _session = StateObject(wrappedValue: BrowserSession(site: site))
        self.onChange = onChange
    }

    var body: some View {
        if let m = session.current {
            BrowserChrome(model: m, session: session,
                          onModeChange: { mode in
                              session.setMode(mode)
                              onChange(session.site)
                          },
                          onFlashChange: { on in
                              session.setFlash(on)
                              onChange(session.site)
                          },
                          onClose: { dismiss() })
                .id(m.id)
        } else {
            Color.clear.onAppear { dismiss() }   // đã đóng hết thẻ
        }
    }
}

struct BrowserChrome: View {
    @ObservedObject var model: BrowserModel
    @ObservedObject var session: BrowserSession
    let onModeChange: (DeviceMode) -> Void
    let onFlashChange: (Bool) -> Void
    let onClose: () -> Void

    @State private var field = ""
    @FocusState private var focused: Bool
    @State private var showDownloads = false
    @State private var showBookmarks = false
    @State private var showTabs = false
    @State private var confirmClear = false
    @State private var toast: String?
    @ObservedObject private var dm = DownloadManager.shared
    @ObservedObject private var bm = BookmarkStore.shared

    private func showToast(_ t: String) {
        toast = t
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { toast = nil }
    }

    private func copy(_ text: String, _ msg: String) {
        guard !text.isEmpty else { return }
        UIPasteboard.general.string = text
        showToast(msg)
    }

    private func toggleBookmark() {
        let url = model.addressText
        guard !url.isEmpty else { return }
        let had = bm.contains(url)
        bm.toggle(url: url, title: model.pageTitle)
        showToast(had ? "Đã bỏ dấu trang" : "Đã thêm dấu trang")
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button { onClose() } label: { Image(systemName: "xmark") }
                TextField("Địa chỉ hoặc từ khóa", text: $field)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .keyboardType(.webSearch).submitLabel(.go)
                    .focused($focused)
                    .onSubmit { model.load(field); focused = false }
                Menu {
                    Picker("Giả làm thiết bị", selection: Binding(
                        get: { session.mode },
                        set: { onModeChange($0) })) {
                        ForEach(DeviceMode.allCases) { Text($0.title).tag($0) }
                    }
                } label: { Image(systemName: "desktopcomputer") }
                Button { showDownloads = true } label: {
                    Image(systemName: dm.active.isEmpty ? "arrow.down.circle" : "arrow.down.circle.fill")
                }
            }
            .padding(.horizontal).padding(.vertical, 8)

            if model.progress < 1 { ProgressView(value: model.progress) }
            if let a = dm.active.first {
                Text("Đang tải: \(a.name) (\(Int(a.progress * 100))%)")
                    .font(.caption).lineLimit(1).padding(.vertical, 4)
            }
            WebContainer(webView: model.webView)

            HStack {
                Button { model.webView.goBack() } label: { Image(systemName: "chevron.left") }
                    .disabled(!model.canGoBack)
                Spacer()
                Button { model.webView.goForward() } label: { Image(systemName: "chevron.right") }
                    .disabled(!model.canGoForward)
                Spacer()
                Button { model.webView.reload() } label: { Image(systemName: "arrow.clockwise") }
                Spacer()
                Button { toggleBookmark() } label: {
                    Image(systemName: bm.contains(model.addressText) ? "star.fill" : "star")
                }
                Spacer()
                Button { showTabs = true } label: {
                    ZStack {
                        Image(systemName: "square.on.square")
                        Text("\(session.tabs.count)").font(.system(size: 9, weight: .bold)).offset(x: 1.5, y: 1.5)
                    }
                }
                Spacer()
                Menu {
                    if RuffleAssets.available {
                        Toggle(isOn: Binding(get: { session.flash }, set: { onFlashChange($0) })) {
                            Label("Flash (Ruffle)", systemImage: "bolt.fill")
                        }
                    }
                    Button { session.addTab() } label: { Label("Thẻ mới", systemImage: "plus.square") }
                    Button { session.close(model) } label: { Label("Đóng thẻ này", systemImage: "xmark.square") }
                    Button { showBookmarks = true } label: { Label("Dấu trang của tôi", systemImage: "book") }
                    Button { copy(model.addressText, "Đã sao chép liên kết") } label: {
                        Label("Sao chép liên kết", systemImage: "link")
                    }
                    Button { copy(model.pageTitle, "Đã sao chép tiêu đề") } label: {
                        Label("Sao chép tiêu đề", systemImage: "textformat")
                    }
                    Button {
                        if let t = UIPasteboard.general.string { model.load(t) }
                    } label: { Label("Dán và mở", systemImage: "doc.on.clipboard") }
                    if let u = URL(string: model.addressText) {
                        ShareLink(item: u) { Label("Chia sẻ trang", systemImage: "square.and.arrow.up") }
                        Button { UIApplication.shared.open(u) } label: {
                            Label("Mở bằng Safari", systemImage: "safari")
                        }
                    }
                    Button { model.showFind() } label: { Label("Tìm trong trang", systemImage: "magnifyingglass") }
                    Button { showDownloads = true } label: { Label("Tải xuống", systemImage: "arrow.down.circle") }
                    Button(role: .destructive) { confirmClear = true } label: {
                        Label("Xóa dữ liệu đăng nhập trang này", systemImage: "trash")
                    }
                } label: { Image(systemName: "ellipsis.circle") }
            }
            .padding(.horizontal, 20).padding(.vertical, 10)
        }
        .onChange(of: model.addressText) { _, new in if !focused { field = new } }
        .onAppear { field = model.addressText }
        .sheet(isPresented: $showDownloads) { DownloadsView() }
        .sheet(isPresented: $showBookmarks) { BookmarksView { model.load($0) } }
        .sheet(isPresented: $showTabs) { TabsView(session: session) }
        .confirmationDialog("Xóa cookie và dữ liệu đăng nhập của mục này?", isPresented: $confirmClear,
                            titleVisibility: .visible) {
            Button("Xóa", role: .destructive) { model.clearData() }
            Button("Hủy", role: .cancel) {}
        }
        .overlay(alignment: .bottom) {
            if let t = toast {
                Text(t).font(.footnote).padding(.horizontal, 14).padding(.vertical, 8)
                    .background(.ultraThinMaterial, in: Capsule())
                    .padding(.bottom, 70).transition(.opacity)
            }
        }
        .animation(.easeInOut, value: toast)
    }
}

// MARK: - Danh sách thẻ
struct TabRow: View {
    @ObservedObject var model: BrowserModel
    let isCurrent: Bool
    let select: () -> Void
    let close: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text(model.pageTitle.isEmpty ? "Thẻ mới" : model.pageTitle)
                    .font(.headline).lineLimit(1)
                Text(model.addressText).font(.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer()
            if isCurrent { Image(systemName: "checkmark").foregroundStyle(.blue) }
            Button(action: close) { Image(systemName: "xmark.circle.fill").foregroundStyle(.secondary) }
                .buttonStyle(.borderless)
        }
        .contentShape(Rectangle())
        .onTapGesture(perform: select)
    }
}

struct TabsView: View {
    @ObservedObject var session: BrowserSession
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                ForEach(session.tabs) { t in
                    TabRow(model: t, isCurrent: t.id == session.current?.id,
                           select: { session.selected = t.id; dismiss() },
                           close: { session.close(t) })
                }
            }
            .navigationTitle("Thẻ (\(session.tabs.count))")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { session.addTab(); dismiss() } label: { Image(systemName: "plus") }
                }
                ToolbarItem(placement: .confirmationAction) { Button("Xong") { dismiss() } }
            }
        }
    }
}
