import SwiftUI

struct Bookmark: Identifiable, Codable, Hashable {
    var id = UUID()
    var title: String
    var url: String
}

final class BookmarkStore: ObservableObject {
    static let shared = BookmarkStore()
    @Published var items: [Bookmark] = [] { didSet { save() } }
    private let key = "pcbrowser.bookmarks"

    private init() {
        if let d = UserDefaults.standard.data(forKey: key),
           let s = try? JSONDecoder().decode([Bookmark].self, from: d) { items = s }
    }

    private func save() {
        if let d = try? JSONEncoder().encode(items) { UserDefaults.standard.set(d, forKey: key) }
    }

    func contains(_ url: String) -> Bool { items.contains { $0.url == url } }

    func toggle(url: String, title: String) {
        if let i = items.firstIndex(where: { $0.url == url }) {
            items.remove(at: i)
        } else {
            let name = title.isEmpty ? (URL(string: url)?.host ?? url) : title
            items.insert(Bookmark(title: name, url: url), at: 0)
        }
    }
}

struct BookmarksView: View {
    @ObservedObject private var store = BookmarkStore.shared
    @Environment(\.dismiss) private var dismiss
    let onOpen: (String) -> Void

    var body: some View {
        NavigationStack {
            List {
                if store.items.isEmpty {
                    Text("Chưa có dấu trang. Bấm ngôi sao ở thanh dưới để thêm.")
                        .foregroundStyle(.secondary)
                }
                ForEach(store.items) { b in
                    Button { onOpen(b.url); dismiss() } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(b.title).font(.headline).lineLimit(1)
                            Text(b.url).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                        }
                    }
                    .contextMenu {
                        Button { UIPasteboard.general.string = b.url } label: {
                            Label("Sao chép liên kết", systemImage: "link")
                        }
                        Button { UIPasteboard.general.string = b.title } label: {
                            Label("Sao chép tiêu đề", systemImage: "textformat")
                        }
                    }
                }
                .onDelete { store.items.remove(atOffsets: $0) }
            }
            .navigationTitle("Dấu trang")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Xong") { dismiss() } } }
        }
    }
}
