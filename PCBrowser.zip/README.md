# Trình duyệt PC (iOS)
Mở bất kỳ trang web nào với giao diện máy tính (giả Windows Chrome/Edge hoặc Mac Safari).
Mỗi mục có kho cookie riêng -> đăng nhập nhiều tài khoản cùng một trang. Yêu cầu iOS 17+.

Build: đẩy lên GitHub -> Actions -> "Build IPA" -> tải artifact PCBrowser-ipa (IPA chưa ký, cần ký lại khi cài).
Hoặc trên Mac: `brew install xcodegen && xcodegen generate` rồi mở PCBrowser.xcodeproj.

## Flash (Ruffle 0.7.1)
- Bật "Flash (Ruffle)" trong menu ba chấm của từng trang để Ruffle thay nội dung Flash trên trang (thử nghiệm, một số trang có chính sách bảo mật CSP sẽ chặn).
- File `.swf` đã tải về: bấm vào trong màn hình Tải xuống để chơi bằng Ruffle (cách này ổn định hơn).
- Ruffle: MIT/Apache-2.0, file giấy phép nằm trong Resources/ruffle.
